with open('meu_arquivo.txt', 'w', encoding='utf-8') as arquivo:
    arquivo.write('Olá!')

print('Arquivo criado e string "Olá!" salva com sucesso!')