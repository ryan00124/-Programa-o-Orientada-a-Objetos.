with open('decrescente.txt', 'w', encoding='utf-8') as arquivo:
    for i in range(100, 0, -1):
        arquivo.write(str(i) + '\n')

print('Arquivo "decrescente.txt" criado com números de 100 a 1!')