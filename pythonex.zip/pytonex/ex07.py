try:
    idade = int(input("Digite sua idade: "))
    print(f"Idade cadastrada: {idade} anos")
except ValueError:
    print("Por favor, insira uma idade válida.")