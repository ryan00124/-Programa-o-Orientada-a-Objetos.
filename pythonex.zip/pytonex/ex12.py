try:
    nome_arquivo = input("Digite o nome do arquivo .txt: ")
    with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
        conteudo = arquivo.read()
        print("\nArquivo aberto com sucesso!")
        print(f"Conteúdo:\n{conteudo}")
except FileNotFoundError:
    print("Arquivo não encontrado.")