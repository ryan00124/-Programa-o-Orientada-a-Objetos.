try:
    dia = int(input("Digite o dia do mês para agendar (1-31): "))
    
    if dia < 1 or dia > 31:
        raise ValueError()
    
    print(f"Consulta agendada para o dia {dia}!")
except ValueError:
    print("Dia inválido para agendamento.")