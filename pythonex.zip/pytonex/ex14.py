try:
    nome_produto = input("Digite o nome do produto: ")
    preco = float(input("Digite o preço do produto: R$ "))
    
    print(f"\nProduto cadastrado com sucesso!")
    print(f"Produto: {nome_produto}")
    print(f"Preço: R$ {preco:.2f}")
except ValueError:
    print("Preço inválido. Digite apenas números para o valor do produto.")