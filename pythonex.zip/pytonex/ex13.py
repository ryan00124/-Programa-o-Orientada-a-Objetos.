try:
    valor_total = float(input("Digite o valor total da conta: R$ "))
    num_pessoas = int(input("Digite o número de pessoas: "))
    
    if num_pessoas <= 0:
        raise ValueError()
    
    valor_por_pessoa = valor_total / num_pessoas
    print(f"\nCada pessoa pagará: R$ {valor_por_pessoa:.2f}")
except (ValueError, ZeroDivisionError):
    print("Número de pessoas inválido para divisão da conta.")