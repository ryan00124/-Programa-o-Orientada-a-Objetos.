def realizar_saque(saldo, valor_saque):
    if valor_saque > saldo:
        raise ValueError("Saldo insuficiente para realizar o saque.")
    return saldo - valor_saque

try:
    saldo_conta = float(input("Digite o saldo da conta: R$ "))
    valor = float(input("Digite o valor do saque: R$ "))
    
    novo_saldo = realizar_saque(saldo_conta, valor)
    print(f"\nSaque realizado com sucesso!")
    print(f"Novo saldo: R$ {novo_saldo:.2f}")
except ValueError as e:
    print(e)