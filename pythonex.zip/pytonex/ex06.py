class Aluno:
    def __init__(self, nome, ra, email, curso, turma):
        self.nome = nome
        self.ra = ra
        self.email = email
        self.curso = curso
        self.turma = turma
    
   
    def cadastrar_aluno():
        print("\n=== CADASTRAR ALUNO ===")
        dados = [input(f"{campo}: ") for campo in ["Nome", "RA", "Email", "Curso", "Turma"]]
        with open('alunos.txt', 'a', encoding='utf-8') as f:
            f.write(';'.join(dados) + '\n')
        print(f"Aluno {dados[0]} cadastrado!")
    
   
    def listar_alunos():
        print("\n=== ALUNOS CADASTRADOS ===")
        try:
            with open('alunos.txt', 'r', encoding='utf-8') as f:
                for i, linha in enumerate(f, 1):
                    dados = linha.strip().split(';')
                    print(f"\n{i}. {dados[0]} | RA: {dados[1]} | {dados[2]} | {dados[3]} | {dados[4]}")
        except FileNotFoundError:
            print("Nenhum aluno cadastrado.")
    

    def remover_aluno():
        print("\n=== REMOVER ALUNO ===")
        ra = input("RA do aluno: ")
        try:
            with open('alunos.txt', 'r', encoding='utf-8') as f:
                linhas = [l for l in f if l.split(';')[1] != ra]
            with open('alunos.txt', 'w', encoding='utf-8') as f:
                f.writelines(linhas)
            print("Aluno removido!" if linhas else "RA não encontrado.")
        except FileNotFoundError:
            print("Arquivo não existe.")

while True:
    print("\n1.Cadastrar 2.Listar 3.Remover 4.Sair")
    op = input("Opção: ")
    if op == '1': Aluno.cadastrar_aluno()
    elif op == '2': Aluno.listar_alunos()
    elif op == '3': Aluno.remover_aluno()
    elif op == '4': break