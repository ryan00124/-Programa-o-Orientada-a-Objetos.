lista_frases = []

print('Digite frases (digite "sair" para finalizar):')

while True:
    frase = input('Frase: ')
    
    if frase.lower() == 'sair':
        break
    
    lista_frases.append(frase)

# Salvar frases no arquivo
with open('frases.txt', 'w', encoding='utf-8') as arquivo:
    for frase in lista_frases:
        arquivo.write(frase + '\n')

print(f'\n{len(lista_frases)} frase(s) salva(s) no arquivo "frases.txt"!')