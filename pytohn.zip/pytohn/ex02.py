with open('meu_arquivo.txt', 'r', encoding='utf-8') as arquivo:
    conteudo = arquivo.read()

print('Conteúdo do arquivo:')
print(conteudo)