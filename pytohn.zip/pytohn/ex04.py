with open('crescente.txt', 'w', encoding='utf-8') as arquivo:
    numeros = [str(i) for i in range(1, 101)]
    arquivo.write(';'.join(numeros))

print('Arquivo "crescente.txt" criado com números de 1 a 100!')