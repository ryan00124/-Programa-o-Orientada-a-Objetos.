def imprime_lista(lista):
    for item in lista:
         print(item)

frutas = ["maça", "banana", "laranja", "uva"]
numeros = [1, 2, 3, 4, 5, 67, 9, 20]


imprime_lista(numeros)